// FSP.DMRCrack - GPU-accelerated ARC4 key recovery for DMR communications
// Copyright (C) 2026 FSP-Labs
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see https://www.gnu.org/licenses/.

/*
 * lang.h - Internationalization string table
 *
 * All user-visible strings are accessed through the global g_lang struct.
 * To add a new language, create lang_XX.c defining the same Lang struct
 * and link it instead of (or conditionally with) lang_en.c.
 */
#ifndef LANG_H
#define LANG_H

typedef struct {
    /* ---- Static labels ---- */
    const char *label_audio;
    const char *label_file;
    const char *label_start_key;
    const char *label_end_key;
    const char *label_threads;
    const char *label_samples;
    const char *label_gpu_pct;       /* "GPU %:" */
    const char *label_temp_limit;    /* "Max C:" - GPU auto-pause threshold */

    /* ---- Metric tile titles ---- */
    const char *tile_throughput;     /* "THROUGHPUT" */
    const char *tile_progress;       /* "PROGRESS" */
    const char *tile_candidate;      /* "BEST CANDIDATE" */

    /* ---- Tile body formats ---- */
    const char *tile_cpu_only;            /* "CPU only" / "Solo CPU" */
    const char *tile_split_fmt;           /* "GPU  %s  .  CPU  %s" */
    const char *tile_score_fmt;           /* "Score  %.2f" / "Puntuacion  %.2f" */
    const char *tile_progress_meta_fmt;   /* "%s keys   .   ETA  %s   .   elapsed  %s" */
    const char *tile_gpu_temp_fmt;        /* "GPU  %d C" */
    const char *tile_gpu_temp_paused_fmt; /* "GPU  %d C - cooling (paused)" */

    /* ---- Empty / idle states ---- */
    const char *empty_hint;               /* "Load a .bin or demodulate a recording, then Start" */
    const char *no_candidate_hint;        /* "No key found above threshold" */
    const char *diag_best_fmt;            /* "best seen  %.1f/burst over %d bursts" */
    const char *status_idle;              /* "Idle" */
    const char *status_searching;         /* "Searching..." */
    const char *graph_waiting;            /* "waiting for data" */

    /* ---- Recovered-key confidence verdict (strict KMI9 / Hytera modes) ---- */
    const char *conf_confirmed;           /* "CONFIRMED" */
    const char *conf_unverified;          /* "UNVERIFIED - confirm with DSD-FME" */
    const char *conf_no_key;              /* "No confirmed key" */
    const char *conf_searching;           /* "Searching - no confirmed key yet" */
    const char *conf_sigma_fmt;           /* "  %.1f sigma" (appended to the verdict) */

    /* ---- KPA silence badge ---- */
    const char *kpa_silence_fmt;     /* "KPA: %u silence frames" / "KPA: %u frames de silencio" */

    /* ---- Status strip ---- */
    const char *status_backend_cuda; /* "CUDA GPU" */
    const char *status_backend_cpu;  /* "CPU" */
    const char *status_no_gpu;       /* "No GPU" header badge when GPU init fails */
    const char *msg_cuda_fallback;   /* "CUDA error - continued on CPU" */
    const char *confirm_run_anyway;  /* appended to a classify warning before a Yes/No prompt */

    /* ---- Payload validation ---- */
    const char *val_payloads_ok;     /* "%zu payloads . KMI9: %zu/%zu . KID=%02X" */
    const char *val_align_warn;      /* "! Burst alignment off" */
    const char *warn_low_payloads_n; /* "! Only %zu payloads - low confidence, risk of false positive" */

    /* ---- Buttons ---- */
    const char *btn_demodulate;
    const char *btn_export;
    const char *btn_start;
    const char *btn_pause;
    const char *btn_resume;
    const char *btn_stop;
    const char *btn_ready;

    /* ---- Demodulation status / errors ---- */
    const char *status_demodulating;          /* "Demodulating with DSD-FME... [1/2]" */
    const char *status_converting;            /* "Converting DSP to BIN... [2/2]"     */
    const char *status_demod_in_memory;       /* "(demodulated in memory)"             */
    const char *err_demod_already_running;    /* "Demodulation already in progress"    */
    const char *err_demod_thread;             /* "Error creating demodulation thread"  */
    const char *err_no_audio_selected;
    const char *err_audio_not_found;
    const char *err_path_has_quotes;
    const char *err_cygwin_dlls_missing;
    const char *err_dll_not_found_exit;
    const char *err_dsd_failed;               /* "DSD-FME failed. Check .dslog.txt"   */
    const char *err_dsd_launch;               /* "Error launching DSD-FME"            */
    const char *err_no_dsp_output;
    const char *err_dsp_conversion;
    const char *err_dsd_missing;              /* "Error: missing DSD-FME (tools\dsd-fme.exe)" */
    const char *err_dsd_missing_detail;       /* Long multi-line MessageBox text */
    const char *warn_dsd_missing_startup;     /* "WARNING: dsd-fme.exe not found ..." */
    const char *msg_demod_ok_fmt;             /* "OK: %zu payloads -> %s" */
    const char *err_dsd_detail_fmt;           /* "%s (exit %lu)\n\nLog: %s\n\n%s" */
    const char *err_no_dsp_detail_fmt;        /* "%s\n\nLog: %s\n\ndsd-fme output:\n%s" */
    const char *lbl_empty_log;                /* "(empty log)" */
    const char *lbl_empty_log_no_output;      /* "(empty log - dsd-fme produced no output)" */
    const char *err_py_script_missing;        /* "Error: missing tools\dsdfme_dsp_to_bin.py"  */
    const char *err_bin_load;                 /* "Error loading generated BIN"                */

    /* ---- Listen: decrypt recovered audio to WAV (DSD-FME -1 <key> -w) ---- */
    const char *btn_listen;                   /* "Listen" / "Escuchar"                        */
    const char *status_decrypting;            /* "Decrypting audio with DSD-FME..."           */
    const char *err_listen_already_running;   /* "Decryption already in progress"             */
    const char *err_listen_thread;            /* "Error creating decryption thread"           */
    const char *err_listen_no_source;         /* "Select the source WAV to play decrypted audio" */
    const char *err_listen_no_key;            /* "No recovered key yet"                       */
    const char *msg_listen_ok_fmt;            /* "Decrypted audio: %s" */

    /* ---- Brute-force validation errors ---- */
    const char *err_no_bin_selected;
    const char *err_start_key_invalid;
    const char *err_end_key_invalid;
    const char *err_threads_empty;
    const char *err_threads_range;            /* "Threads must be 1..64"              */
    const char *err_samples_empty;
    const char *err_samples_range;            /* "Samples must be 1..100000"          */
    const char *warn_few_payloads;            /* shown when payload count < 64        */

    /* ---- Export ---- */
    const char *err_no_payloads_export;
    const char *msg_exported;                 /* printf format: %zu lines, path       */
    const char *dlg_export_filter;            /* file-open filter string (double-NUL) */

    /* ---- Fatal / startup errors ---- */
    const char *err_wnd_class;
    const char *err_wnd_create;

    /* ---- Engine start errors (bruteforce.cu set_error paths) ---- */
    const char *err_search_already_active;
    const char *err_start_gt_end;
    const char *err_end_exceeds_40bit;
    const char *err_no_payloads_loaded;
    const char *err_pause_event_failed;
    const char *err_oom_cpu_threads;
    const char *err_create_cpu_threads;
    const char *err_oom_handles;
    const char *err_create_cuda_thread;

    /* ---- Status panel format strings ---- */
    const char *fmt_keys_tested;       /* "Keys tested: %llu / %llu (%.2f%%)" */
    const char *fmt_speed;             /* "Speed: %.2f keys/s"                */
    const char *fmt_time;              /* "Time: %s  |  ETA: %s"             */
    const char *fmt_backend;           /* "Backend: %s"                       */
    const char *fmt_best_candidate;    /* "Best candidate: %s"                */
    const char *fmt_best_score;        /* "Best score: %s"                    */
    const char *fmt_status;            /* "Status: %s"                        */
    const char *fmt_cuda_error;        /* "CUDA error: %s"                    */
    const char *warn_gpu_not_found;    /* Shown once when GPU init fails at search start */
    const char *fmt_payloads_loaded;   /* "%zu payloads loaded"               */

    /* ---- State labels ---- */
    const char *state_running;         /* "RUNNING"  */
    const char *state_paused;          /* "PAUSED"   */
    const char *state_stopped;         /* "STOPPED"  */

    /* ---- Graph titles ---- */
    const char *graph_keys_title;      /* "Keys/s (history)"       */
    const char *graph_score_title;     /* "Best score (evolution)" */

    /* ---- File dialog filters ---- */
    const char *dlg_bin_filter;        /* payload picker: ".bin" + DSD-FME DSP dumps */
    const char *dlg_audio_filter;      /* "DMR Audio (*.wav;...)\0...\0All files (*.*)\0*.*\0" */

    /* ---- DSP-dump auto-conversion (payload picker) ---- */
    const char *dsp_src_prefix;        /* prefix when a payload was converted from a DSP dump */
    const char *dsp_no_log_note;       /* appended when no PI log was found alongside the DSP  */

    /* ---- Copy / notification ---- */
    const char *btn_copy_key;          /* "Copy"                              */
    const char *msg_key_found;         /* "Key found! %s (score: %.1f)"      */
    const char *msg_key_copied;        /* "Key copied to clipboard"           */

    /* ---- Help dialog ---- */
    const char *btn_help;              /* "Help" (button label)               */
    const char *help_title;            /* Help window title                   */
    const char *help_content;          /* Full help text (scrollable)         */

    /* ---- First-run terms-of-use acceptance gate ---- */
    const char *gate_title;            /* "FSP.DMRCrack - Terms of Use"       */
    const char *gate_body;             /* authorized-use affirmation (Yes/No) */

} Lang;

#ifdef __cplusplus
extern "C" {
#endif

/* All available language tables. */
extern const Lang g_lang_en;
extern const Lang g_lang_es;

/* Active language pointer - switch at runtime to change language.
 * Use the g_lang macro so all existing g_lang.xxx references work unchanged. */
extern const Lang *g_lang_ptr;

#ifdef __cplusplus
}
#endif

#define g_lang (*g_lang_ptr)

#endif /* LANG_H */
